动画地址：[](https://daneden.github.io/animate.css/)

bootstrap 
	<button class="btn btn-primary">注册</button>