<template>
	<view>
		<swiper class="swiper" indicator-dots autoplay interval="2000" duration="1000" circular>
			<block v-for="(item,index) in resdata" :key="index">
				<swiper-item>
					<view class="swiper-item" @tap="event(item)">
						<image :src="item.src" lazy-load style="height: 350rpx;"></image>
					</view>
				</swiper-item>
			</block>
		</swiper>
	</view>
</template>

<script>
	export default {
		props:{
			resdata:Array
		},
		methods:{
			event(item){
				console.log("轮播图被点击了..."+item.src)
			}
		}
	}
</script>

<style>

</style>
