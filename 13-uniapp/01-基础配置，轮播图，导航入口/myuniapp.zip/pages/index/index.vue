<template>
	<view>
		<!-- 轮播图组件 -->
		<swiperImage :resdata="swipers"></swiperImage>
		<!-- 分类组件 -->
		<indexNav  :resdata="indexnavs"></indexNav>
	</view>
</template>

<script>
	import swiperImage from "@/components/index/swiper-image.vue"
	import indexNav from "@/components/index/index-nav.vue"
	export default {
		components:{
			swiperImage,
			indexNav
		},
		data() {
			return {
				swipers:[
					{
						src:"../../static/images/demo/demo4.jpg"
					},
					{
						src:"../../static/images/demo/demo4.jpg"
					},
					{
						src:"../../static/images/demo/demo4.jpg"
					}
				],
				indexnavs:[
					{ src:"/static/images/indexnav/1.png",text:"新品发布1"},
					{ src:"/static/images/indexnav/2.gif",text:"新品发布2"},
					{ src:"/static/images/indexnav/3.gif",text:"新品发布3"},
					{ src:"/static/images/indexnav/4.gif",text:"新品发布4"},
					{ src:"/static/images/indexnav/5.gif",text:"新品发布5"},
					{ src:"/static/images/indexnav/6.gif",text:"新品发布"},
					{ src:"/static/images/indexnav/7.gif",text:"新品发布"},
					{ src:"/static/images/indexnav/8.gif",text:"新品发布"},
					{ src:"/static/images/indexnav/9.gif",text:"新品发布"},
					{ src:"/static/images/indexnav/10.gif",text:"新品发布"},
				]
			}
		},
		onLoad() {

		},
		methods: {

		}
	}
</script>

<style>
</style>
