<template>
	<view class="d-flex">
		<image :src="resdata.big.src" style="width: 373rpx; height: 530rpx; border-right: 2rpx solid #fbfffe;"
		 lazy-load mode=""></image>
		<view class="d-flex flex-column">
			<image :src="resdata.smalltop.src" style="width: 375rpx; height: 264rpx; border-bottom: 2rpx solid #fbfffe;"
			 mode=""></image>
			<image :src="resdata.smallbottom.src" style="width: 375rpx; height: 264rpx;" mode=""></image>
		</view>
	</view>
</template>

<script>
	export default {
		props: {
			resdata: Object
		},
	}
</script>

<style>
</style>
