<template>
	<view>
		<!-- 轮播图组件 -->
		<swiperImage :resdata="swipers"></swiperImage>
		<!-- 分类组件 -->
		<indexNav :resdata="indexnavs"></indexNav>
		<!-- 线 -->
		<divider></divider>
		<!-- 小广告 -->
		<threeAdv :resdata="threeAdv"></threeAdv>
		<!-- 线 -->
		<divider></divider>
		<!-- 名片 -->
		<cart>
			<block slot="title">每日精选</block>
			<image style="height: 301rpx;" src="/static/images/demo/demo4.jpg" mode=""></image>
		</cart>
		<!-- 列表 750-5=745/2=372.5 -->
		<view class="row">
			<block v-for="(vlist,listindex) in goodsList" :key="listindex">
				<commonList :item="vlist" :index="listindex"></commonList>
			</block>
		</view>

	</view>
</template>

<script>
	import swiperImage from "@/components/index/swiper-image.vue"
	import indexNav from "@/components/index/index-nav.vue"
	import threeAdv from "@/components/index/three-adv.vue"
	import cart from "@/components/common/card.vue"
	import commonList from "@/components/common/common-list.vue"
	export default {
		components: {
			swiperImage,
			indexNav,
			threeAdv,
			cart,
			commonList
		},
		data() {
			return {
				swipers: [{
						src: "../../static/images/demo/demo4.jpg"
					},
					{
						src: "../../static/images/demo/demo4.jpg"
					},
					{
						src: "../../static/images/demo/demo4.jpg"
					}
				],
				indexnavs: [{
						src: "/static/images/indexnav/1.png",
						text: "新品发布1"
					},
					{
						src: "/static/images/indexnav/2.gif",
						text: "新品发布2"
					},
					{
						src: "/static/images/indexnav/3.gif",
						text: "新品发布3"
					},
					{
						src: "/static/images/indexnav/4.gif",
						text: "新品发布4"
					},
					{
						src: "/static/images/indexnav/5.gif",
						text: "新品发布5"
					},
					{
						src: "/static/images/indexnav/6.gif",
						text: "新品发布"
					},
					{
						src: "/static/images/indexnav/7.gif",
						text: "新品发布"
					},
					{
						src: "/static/images/indexnav/8.gif",
						text: "新品发布"
					},
					{
						src: "/static/images/indexnav/9.gif",
						text: "新品发布"
					},
					{
						src: "/static/images/indexnav/10.gif",
						text: "新品发布"
					},
				],
				threeAdv: {
					big: {
						src: "/static/images/demo/demo1.jpg"
					},
					smalltop: {
						src: "/static/images/demo/demo2.jpg"
					},
					smallbottom: {
						src: "/static/images/demo/demo3.jpg"
					}
				},
				goodsList: [{
						cover: "/static/images/demo/list/1.jpg",
						title: "米家空调",
						desc: "1.5匹变频",
						oprice: 2699,
						pprice: 1399
					},
					{
						cover: "/static/images/demo/list/1.jpg",
						title: "米家空调",
						desc: "1.5匹变频",
						oprice: 2699,
						pprice: 1399
					},
					{
						cover: "/static/images/demo/list/1.jpg",
						title: "米家空调",
						desc: "1.5匹变频",
						oprice: 2699,
						pprice: 1399
					},
					{
						cover: "/static/images/demo/list/1.jpg",
						title: "米家空调",
						desc: "1.5匹变频",
						oprice: 2699,
						pprice: 1399
					},
					{
						cover: "/static/images/demo/list/1.jpg",
						title: "米家空调",
						desc: "1.5匹变频",
						oprice: 2699,
						pprice: 1399
					},
					{
						cover: "/static/images/demo/list/1.jpg",
						title: "米家空调",
						desc: "1.5匹变频",
						oprice: 2699,
						pprice: 1399
					},
					{
						cover: "/static/images/demo/list/1.jpg",
						title: "米家空调",
						desc: "1.5匹变频",
						oprice: 2699,
						pprice: 1399
					},
				]
			}
		},
		onLoad() {

		},
		methods: {

		}
	}
</script>

<style>
</style>
