<script>
	export default {
		onLaunch: function() {
			console.log('App Launch')
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		}
	}
</script>

<style>
	@import './common/uni.css';   /* 引入uniapp中的样式 */
	@import './common/common.css'; /* 引入通用样式 */
	@import './common/zcm-main.css'; /* UI基础库 */
</style>
