<template>
	<view style="height: 18rpx; background: #faf7f7;"></view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style>

</style>
